# Psyjaciele — statyczna makieta

Aktualna makieta strony głównej Przychodni Weterynaryjnej Psyjaciele. HTML, CSS i JavaScript oraz lokalne ilustracje, zdjęcia i fonty. Repozytorium nie jest połączone z publikacją produkcyjnej strony WordPress.

## Podgląd online

Makieta jest opublikowana przez GitHub Pages: https://stefankot.github.io/psyjaciele-makieta/

Repozytorium jest publiczne. Zmiany wysłane do gałęzi `main` automatycznie aktualizują podgląd.

## Uruchomienie

W katalogu repozytorium:

```sh
python3 -m http.server 8765
```

Otwórz `http://127.0.0.1:8765/`. Plik `index.html` przekierowuje do aktualnego `index-min.html`.

## Aktualne pliki

- `index-min.html` — strona główna, teksty, metadane i przypisania palet.
- `minimal.css` — siatka 12 kolumn, zestawy kolorów, układ responsywny i pływający header.
- `minimal.js` — menu, aureola założycielek, pomiar headera i lazy load animowanej ilustracji.
- `motion.js` — zachowany plik wcześniejszych animacji; nie jest ładowany przez stronę.
- `assets/` — lokalne zasoby, biblioteki GSAP/ScrollTrigger, oryginalne ilustracje i statyczne pierwsze klatki.

Podstrony usług, zespołu i polityki prywatności są wcześniejszymi statycznymi kopiami. Bieżące prace projektowe obejmują stronę główną. `index-poprzedni.html` zachowuje wcześniejszą wersję do porównania.

## Stan makiety

Hero mieści się w 96% wysokości okna. Sekcje mają ilustracje (z wyjątkiem sekcji założycielek), a układ korzysta ze wspólnej siatki i zmiennych CSS. Animacje nagłówków, kafli i ilustracji reagujące na scroll są wyłączone. Zachowano animację aureoli założycielek oraz odtwarzanie ilustracji hero. Animowana ilustracja hero ładuje się dopiero w widocznym obszarze i odtwarza się raz.

Makieta zawiera teksty robocze i miejsca na przyszłe zdjęcia. Strona główna ma `noindex,follow`; przed publikacją jako docelowej witryny trzeba potwierdzić aktualność treści biznesowych i zmienić ustawienie indeksowania. GitHub Pages udostępnia podgląd makiety i nie zmienia WordPressa.

Prawa do zdjęć, ilustracji, fontów i bibliotek pozostają przy ich właścicielach. Nagłówki licencyjne bibliotek zachowano w plikach.
