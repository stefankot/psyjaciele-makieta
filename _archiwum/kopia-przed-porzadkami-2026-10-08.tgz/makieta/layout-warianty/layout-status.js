/*
  layout-status.js — „Otwarte teraz” w hero (wariant odważny).
  Godziny jak w nagłówku: Pn–Pt 9:00–20:00, Sob–Nd 10:00–14:00 (czas Warszawy).
  Poza godzinami chip prowadzi do kontaktu i lecznic całodobowych.
*/
(() => {
  const el = document.querySelector('[data-hero-status]');
  if (!el) return;
  const HOURS = { weekday: [9, 20], weekend: [10, 14] };
  const DAYS = ['Nd', 'Pn', 'Wt', 'Śr', 'Cz', 'Pt', 'Sb'];

  function warsawNow() {
    const parts = new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Europe/Warsaw', weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false
    }).formatToParts(new Date());
    const get = t => parts.find(p => p.type === t).value;
    const map = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
    return { day: map[get('weekday')], minutes: (+get('hour') % 24) * 60 + +get('minute') };
  }
  const hoursFor = d => (d === 0 || d === 6 ? HOURS.weekend : HOURS.weekday);
  const fmt = h => `${h}:00`;

  function render() {
    const { day, minutes } = warsawNow();
    const [open, close] = hoursFor(day);
    let text, state;
    if (minutes >= open * 60 && minutes < close * 60) {
      const left = close * 60 - minutes;
      state = left <= 60 ? 'closing' : 'open';
      text = left <= 60 ? `Otwarte jeszcze do ${fmt(close)}` : `Otwarte teraz — do ${fmt(close)}`;
    } else {
      state = 'closed';
      let d = day;
      let dayLabel = 'dziś';
      if (minutes >= close * 60) { d = (day + 1) % 7; dayLabel = 'jutro'; }
      text = `Zamknięte — ${dayLabel} od ${fmt(hoursFor(d)[0])}. Nagły przypadek?`;
    }
    el.textContent = text;
    el.dataset.state = state;
    el.setAttribute('href', state === 'closed' ? '#after-hours-title' : '#zapraszamy');
    el.hidden = false;
  }
  render();
  setInterval(render, 60000);
})();
