<!-- generated: psyjaciele-podstrony -->
# Prompty do generowania obrazów (EN)

Jeden blok na obraz; nazwa pliku w drugim wierszu każdego bloku. Obrazy z kolumny „źródło” oznaczone jako *prawdziwe zdjęcie* najlepiej zastąpić zdjęciem z przychodni (za zgodą opiekunów) — prompt jest wtedy tylko zapasowy.

## uslugi-00-hero

```text
# Ilustracja hero
Plik: uslugi-00-hero.png. Narzędzie: wbudowane image_gen.

Use case: scientific-educational illustration. Asset type: website diagram, 1:1 square. Subject: a dog and a cat sitting calmly side by side beside a small stethoscope. Monoline black line art on transparent background, no fill, even stroke width, consistent with the clinic's existing line illustrations. No text, no numbers, no gradients, no shading.

Style references (attach all as image inputs and match their line weight, proportions, calm mood and level of detail; do NOT copy their subjects): assets/illustrations/services/service-internal-a.png, assets/illustrations/services/service-cardiology-b.png, assets/illustrations/services/service-eyes-a.png, assets/illustrations/services/service-dentistry-a.png.
Reject any result that looks generic, glossy, 3D, cartoon-mascot or stock-vector.
```

## uslugi-02-gabinet

```text
# Gabinet zabiegowy
Plik: uslugi-02-gabinet.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 21:9 wide panoramic banner. Subject: a bright empty veterinary examination room, steel table, lamp and cabinets, wide view. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 50 percent of the frame width, generous empty margins left and right. No text, no graphics, no logos, no people's faces.
```

## uslugi-03-mozaika-a

```text
# Pies na stole badań
Plik: uslugi-03-mozaika-a.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 4:5 portrait. Subject: a calm medium-sized dog standing on an examination table, a veterinarian's hand resting on its back, no faces visible. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## uslugi-03-mozaika-b

```text
# Kot w transporterze
Plik: uslugi-03-mozaika-b.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 3:2 landscape. Subject: a cat peeking out of an open carrier lined with a blanket. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## uslugi-03-mozaika-c

```text
# Dłonie przy książeczce zdrowia
Plik: uslugi-03-mozaika-c.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 3:2 landscape. Subject: hands holding a pet health booklet over a table, no faces. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## uslugi-01-recepcja

```text
# Recepcja przychodni
Plik: uslugi-01-recepcja.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 3:2 landscape. Subject: the reception area of a small veterinary clinic, empty counter, a chair and a folded blanket. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## uslugi-04-kot-pies

```text
# Kot i pies obok siebie
Plik: uslugi-04-kot-pies.png. Narzędzie: wbudowane image_gen.

Use case: stylized-concept. Asset type: website cutout, 1:1 square. Subject: a calm grey cat and a small dog sitting side by side, seen from the front. True transparent alpha background, no halo, no drop shadow. Grayscale black-and-white photographic rendering, soft diffused studio light. Subject within the middle 70 percent of the frame. No text, no logos.
```

## interna-01-badanie

```text
# Badanie psa stetoskopem
Plik: interna-01-badanie.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 4:5 portrait. Subject: a veterinarian listening to a calm dog's chest with a stethoscope, face not visible. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## interna-03-pas-gabinet

```text
# Gabinet internisty
Plik: interna-03-pas-gabinet.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 21:9 wide panoramic banner. Subject: a wide view of a veterinary consulting room with a table, scale and cabinet. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 50 percent of the frame width, generous empty margins left and right. No text, no graphics, no logos, no people's faces.
```

## interna-02-schemat-ukladow

```text
# Schemat układów narządowych
Plik: interna-02-schemat-ukladow.svg. Narzędzie: wbudowane image_gen.

Use case: scientific-educational illustration. Asset type: website diagram, 4:3 landscape. Subject: simplified outline of a dog with faint organ systems indicated by line shapes, unlabeled. Monoline black line art on transparent background, no fill, even stroke width, consistent with the clinic's existing line illustrations. No text, no numbers, no gradients, no shading.
```

## interna-04-kontrola

```text
# Kontrola kota
Plik: interna-04-kontrola.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 3:2 landscape. Subject: a cat sitting on an owner's lap during a routine check, no faces. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## lab-01-analizator

```text
# Analizator w gabinecie
Plik: lab-01-analizator.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 3:2 landscape. Subject: a tabletop laboratory analyzer on a clean counter, screen turned off. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## lab-03-pas-laboratorium

```text
# Stanowisko laboratoryjne
Plik: lab-03-pas-laboratorium.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 21:9 wide panoramic banner. Subject: a wide laboratory counter with a microscope and glass slides. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 50 percent of the frame width, generous empty margins left and right. No text, no graphics, no logos, no people's faces.
```

## lab-02-probki

```text
# Probówki z próbkami
Plik: lab-02-probki.png. Narzędzie: wbudowane image_gen.

Use case: stylized-concept. Asset type: website cutout, 1:1 square. Subject: a small rack with empty laboratory sample tubes, labels blank. True transparent alpha background, no halo, no drop shadow. Grayscale black-and-white photographic rendering, soft diffused studio light. Subject within the middle 70 percent of the frame. No text, no logos.
```

## szcz-01-szczepienie

```text
# Szczepienie psa
Plik: szcz-01-szczepienie.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 4:5 portrait. Subject: gloved hands of a veterinarian preparing a vaccination for a calm dog in the background, no needle visible. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## szcz-04-pas-pies-kot

```text
# Pies i kot
Plik: szcz-04-pas-pies-kot.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 21:9 wide panoramic banner. Subject: a dog and a cat sitting side by side, wide banner composition. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 50 percent of the frame width, generous empty margins left and right. No text, no graphics, no logos, no people's faces.
```

## szcz-02-ksiazeczka

```text
# Książeczka szczepień
Plik: szcz-02-ksiazeczka.png. Narzędzie: wbudowane image_gen.

Use case: stylized-concept. Asset type: website cutout, 1:1 square. Subject: a closed pet vaccination booklet, front cover with no text. True transparent alpha background, no halo, no drop shadow. Grayscale black-and-white photographic rendering, soft diffused studio light. Subject within the middle 70 percent of the frame. No text, no logos.
```

## szcz-03-kalendarz

```text
# Schemat osi czasu
Plik: szcz-03-kalendarz.svg. Narzędzie: wbudowane image_gen.

Use case: scientific-educational illustration. Asset type: website diagram, 4:3 landscape. Subject: a simple horizontal timeline with five small markers, no dates. Monoline black line art on transparent background, no fill, even stroke width, consistent with the clinic's existing line illustrations. No text, no numbers, no gradients, no shading.
```

## chir-02-konsultacja

```text
# Konsultacja przed zabiegiem
Plik: chir-02-konsultacja.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 3:2 landscape. Subject: a veterinarian talking with a pet owner next to a dog, faces not visible. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## chir-03-opieka-po

```text
# Pies w kołnierzu
Plik: chir-03-opieka-po.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 4:5 portrait. Subject: a dog resting on a bed wearing a soft recovery collar. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## chir-01-sala-zabiegowa

```text
# Sala zabiegowa
Plik: chir-01-sala-zabiegowa.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 21:9 wide panoramic banner. Subject: a bright empty surgical room with a table and lamp, no instruments in use. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 50 percent of the frame width, generous empty margins left and right. No text, no graphics, no logos, no people's faces.
```

## chir-04-rana-schemat

```text
# Schemat opatrunku
Plik: chir-04-rana-schemat.svg. Narzędzie: wbudowane image_gen.

Use case: scientific-educational illustration. Asset type: website diagram, 4:3 landscape. Subject: simplified line drawing of a dog's leg with a bandage wrap, no wound shown. Monoline black line art on transparent background, no fill, even stroke width, consistent with the clinic's existing line illustrations. No text, no numbers, no gradients, no shading.
```

## kard-01-serce-diagram

```text
# Schemat budowy serca
Plik: kard-01-serce-diagram.svg. Narzędzie: wbudowane image_gen.

Use case: scientific-educational illustration. Asset type: website diagram, 4:3 landscape. Subject: simplified four-chamber heart of a dog in cross-section with unlabeled arrows showing blood flow. Monoline black line art on transparent background, no fill, even stroke width, consistent with the clinic's existing line illustrations. No text, no numbers, no gradients, no shading.
```

## kard-02-echo

```text
# Badanie echo serca
Plik: kard-02-echo.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 3:2 landscape. Subject: an ultrasound probe held against a calm dog's chest, screen not visible. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## kard-04-pies-kot-a

```text
# Pies w gabinecie
Plik: kard-04-pies-kot-a.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 4:5 portrait. Subject: a calm dog sitting in a veterinary room. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## kard-04-pies-kot-b

```text
# Kot na stole
Plik: kard-04-pies-kot-b.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 3:2 landscape. Subject: a cat sitting calmly on an examination table. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## kard-04-pies-kot-c

```text
# Dłoń na grzbiecie
Plik: kard-04-pies-kot-c.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 3:2 landscape. Subject: a veterinarian's hand gently stroking a pet's back. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## kard-03-ekg

```text
# Elektrody EKG
Plik: kard-03-ekg.png. Narzędzie: wbudowane image_gen.

Use case: stylized-concept. Asset type: website cutout, 1:1 square. Subject: a set of ECG electrode clips with cables, neatly arranged. True transparent alpha background, no halo, no drop shadow. Grayscale black-and-white photographic rendering, soft diffused studio light. Subject within the middle 70 percent of the frame. No text, no logos.
```

## usg-01-aparat

```text
# Aparat USG
Plik: usg-01-aparat.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 4:5 portrait. Subject: a veterinary ultrasound machine in a consulting room, screen off. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## usg-02-mapa-ciala

```text
# Mapa ciała do USG
Plik: usg-02-mapa-ciala.svg. Narzędzie: wbudowane image_gen.

Use case: scientific-educational illustration. Asset type: website diagram, 4:3 landscape. Subject: simplified outline of a dog's body with soft rounded zones marking abdominal windows, unlabeled. Monoline black line art on transparent background, no fill, even stroke width, consistent with the clinic's existing line illustrations. No text, no numbers, no gradients, no shading.
```

## usg-04-pas

```text
# Gabinet USG
Plik: usg-04-pas.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 21:9 wide panoramic banner. Subject: wide view of a dim ultrasound room with a table and machine. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 50 percent of the frame width, generous empty margins left and right. No text, no graphics, no logos, no people's faces.
```

## usg-03-badanie

```text
# Badanie USG jamy brzusznej
Plik: usg-03-badanie.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 3:2 landscape. Subject: an ultrasound probe on the shaved belly of a calm dog lying on its back, faces not visible. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## oko-01-oko-diagram

```text
# Schemat budowy oka
Plik: oko-01-oko-diagram.svg. Narzędzie: wbudowane image_gen.

Use case: scientific-educational illustration. Asset type: website diagram, 4:3 landscape. Subject: simplified cross-section of a dog's eye showing cornea, lens and retina as plain shapes. Monoline black line art on transparent background, no fill, even stroke width, consistent with the clinic's existing line illustrations. No text, no numbers, no gradients, no shading.
```

## oko-04-pas-gabinet

```text
# Gabinet okulistyczny
Plik: oko-04-pas-gabinet.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 21:9 wide panoramic banner. Subject: wide view of a veterinary room with a slit lamp on a table. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 50 percent of the frame width, generous empty margins left and right. No text, no graphics, no logos, no people's faces.
```

## oko-02-badanie-lampa

```text
# Badanie lampą szczelinową
Plik: oko-02-badanie-lampa.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 3:2 landscape. Subject: a slit lamp examination of a dog's eye, human faces not visible. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## oko-03-oko-pies

```text
# Portret psa
Plik: oko-03-oko-pies.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 4:5 portrait. Subject: a close portrait of a calm dog looking toward the camera. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## derm-01-badanie-skory

```text
# Badanie skóry psa
Plik: derm-01-badanie-skory.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 4:5 portrait. Subject: hands parting the fur on a dog's back to look at healthy-looking skin, no lesions visible. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## derm-02-pas-skora-siersc

```text
# Sierść z bliska
Plik: derm-02-pas-skora-siersc.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 21:9 wide panoramic banner. Subject: wide macro view of a dog's fur texture. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 50 percent of the frame width, generous empty margins left and right. No text, no graphics, no logos, no people's faces.
```

## derm-03-cytologia

```text
# Mikroskop i szkiełka
Plik: derm-03-cytologia.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 3:2 landscape. Subject: a microscope and glass slides on a clean counter. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## derm-04-pielegnacja

```text
# Szczotka do sierści
Plik: derm-04-pielegnacja.png. Narzędzie: wbudowane image_gen.

Use case: stylized-concept. Asset type: website cutout, 1:1 square. Subject: a pet grooming brush, simple object. True transparent alpha background, no halo, no drop shadow. Grayscale black-and-white photographic rendering, soft diffused studio light. Subject within the middle 70 percent of the frame. No text, no logos.
```

## stom-01-jama-ustna-diagram

```text
# Schemat zęba i dziąsła
Plik: stom-01-jama-ustna-diagram.svg. Narzędzie: wbudowane image_gen.

Use case: scientific-educational illustration. Asset type: website diagram, 4:3 landscape. Subject: simplified cross-section of a dog tooth in the gum, unlabeled. Monoline black line art on transparent background, no fill, even stroke width, consistent with the clinic's existing line illustrations. No text, no numbers, no gradients, no shading.
```

## stom-02-zabieg

```text
# Stanowisko stomatologiczne
Plik: stom-02-zabieg.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 3:2 landscape. Subject: a veterinary dental station with instruments laid out, no animal. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## stom-03-mozaika-a

```text
# Pies z zabawką
Plik: stom-03-mozaika-a.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 4:5 portrait. Subject: a dog holding a rubber toy in its mouth. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## stom-03-mozaika-b

```text
# Szczoteczka
Plik: stom-03-mozaika-b.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 3:2 landscape. Subject: a pet toothbrush and toothpaste on a plain surface. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## stom-03-mozaika-c

```text
# Kot u lekarki
Plik: stom-03-mozaika-c.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 3:2 landscape. Subject: a cat sitting calmly with a veterinarian, face not visible. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## stom-04-pies-szczotka

```text
# Pies ze szczoteczką
Plik: stom-04-pies-szczotka.png. Narzędzie: wbudowane image_gen.

Use case: stylized-concept. Asset type: website cutout, 1:1 square. Subject: a seated dog next to a toothbrush. True transparent alpha background, no halo, no drop shadow. Grayscale black-and-white photographic rendering, soft diffused studio light. Subject within the middle 70 percent of the frame. No text, no logos.
```

## nefr-01-nerki-diagram

```text
# Schemat nerek
Plik: nefr-01-nerki-diagram.svg. Narzędzie: wbudowane image_gen.

Use case: scientific-educational illustration. Asset type: website diagram, 4:3 landscape. Subject: simplified line drawing of two kidneys with ureters, unlabeled. Monoline black line art on transparent background, no fill, even stroke width, consistent with the clinic's existing line illustrations. No text, no numbers, no gradients, no shading.
```

## nefr-02-kot-pije

```text
# Kot przy misce
Plik: nefr-02-kot-pije.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 4:5 portrait. Subject: a cat drinking water from a bowl. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## nefr-03-pas

```text
# Gabinet
Plik: nefr-03-pas.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 21:9 wide panoramic banner. Subject: wide view of a quiet veterinary consulting room. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 50 percent of the frame width, generous empty margins left and right. No text, no graphics, no logos, no people's faces.
```

## nefr-04-badanie-krwi

```text
# Pobranie krwi
Plik: nefr-04-badanie-krwi.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 3:2 landscape. Subject: gloved hands holding a dog's paw with a sample tube nearby, no needle visible. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## uro-01-uklad-moczowy-diagram

```text
# Schemat układu moczowego
Plik: uro-01-uklad-moczowy-diagram.svg. Narzędzie: wbudowane image_gen.

Use case: scientific-educational illustration. Asset type: website diagram, 4:3 landscape. Subject: simplified line drawing of the lower urinary tract, unlabeled. Monoline black line art on transparent background, no fill, even stroke width, consistent with the clinic's existing line illustrations. No text, no numbers, no gradients, no shading.
```

## uro-02-kot-kuweta

```text
# Kot przy kuwecie
Plik: uro-02-kot-kuweta.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 3:2 landscape. Subject: a cat next to a clean litter box. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## uro-04-pies-spacer

```text
# Pies na spacerze
Plik: uro-04-pies-spacer.png. Narzędzie: wbudowane image_gen.

Use case: stylized-concept. Asset type: website cutout, 1:1 square. Subject: a dog standing on a leash, side view. True transparent alpha background, no halo, no drop shadow. Grayscale black-and-white photographic rendering, soft diffused studio light. Subject within the middle 70 percent of the frame. No text, no logos.
```

## uro-03-pas

```text
# Gabinet
Plik: uro-03-pas.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 21:9 wide panoramic banner. Subject: wide view of a quiet veterinary consulting room. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 50 percent of the frame width, generous empty margins left and right. No text, no graphics, no logos, no people's faces.
```

## cis-01-mankiet-diagram

```text
# Schemat mankietu
Plik: cis-01-mankiet-diagram.svg. Narzędzie: wbudowane image_gen.

Use case: scientific-educational illustration. Asset type: website diagram, 4:3 landscape. Subject: simplified drawing of a dog's leg with a blood pressure cuff, unlabeled. Monoline black line art on transparent background, no fill, even stroke width, consistent with the clinic's existing line illustrations. No text, no numbers, no gradients, no shading.
```

## cis-02-pomiar-kot

```text
# Pomiar u kota
Plik: cis-02-pomiar-kot.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 4:5 portrait. Subject: a cat with a small cuff on its paw held gently, faces not visible. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## cis-03-pas-gabinet

```text
# Cichy gabinet
Plik: cis-03-pas-gabinet.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 21:9 wide panoramic banner. Subject: wide view of a quiet veterinary room with a small table. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 50 percent of the frame width, generous empty margins left and right. No text, no graphics, no logos, no people's faces.
```

## cis-04-pomiar-pies

```text
# Pomiar u psa
Plik: cis-04-pomiar-pies.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 3:2 landscape. Subject: a dog lying calmly with a cuff on its leg, faces not visible. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## pasz-01-paszport

```text
# Paszport zwierzęcia
Plik: pasz-01-paszport.png. Narzędzie: wbudowane image_gen.

Use case: stylized-concept. Asset type: website cutout, 1:1 square. Subject: a closed pet passport booklet, cover without text. True transparent alpha background, no halo, no drop shadow. Grayscale black-and-white photographic rendering, soft diffused studio light. Subject within the middle 70 percent of the frame. No text, no logos.
```

## pasz-02-stempel

```text
# Stempel i dokumenty
Plik: pasz-02-stempel.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 3:2 landscape. Subject: a stamp and a document on a desk, no readable text. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## pasz-03-podroz

```text
# Podróż z psem
Plik: pasz-03-podroz.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 21:9 wide panoramic banner. Subject: a suitcase and a pet carrier side by side, wide banner. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 50 percent of the frame width, generous empty margins left and right. No text, no graphics, no logos, no people's faces.
```

## pasz-04-pies-kot-walizka

```text
# Pies obok walizki
Plik: pasz-04-pies-kot-walizka.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 4:5 portrait. Subject: a dog sitting next to a suitcase. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## czip-01-czip-diagram

```text
# Schemat czipa
Plik: czip-01-czip-diagram.svg. Narzędzie: wbudowane image_gen.

Use case: scientific-educational illustration. Asset type: website diagram, 4:3 landscape. Subject: simplified drawing of a microchip beside a dog's shoulder area marked by a small circle, unlabeled. Monoline black line art on transparent background, no fill, even stroke width, consistent with the clinic's existing line illustrations. No text, no numbers, no gradients, no shading.
```

## czip-02-aplikator

```text
# Aplikator czipa przy barku psa
Plik: czip-02-aplikator.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 3:2 landscape. Subject: gloved hands of a veterinarian holding a microchip applicator near the scruff of a calm golden retriever, no needle visible. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## czip-03-pas-zabieg

```text
# Gabinet zabiegowy
Plik: czip-03-pas-zabieg.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 21:9 wide panoramic banner. Subject: wide view of a bright veterinary room with a table and a lamp. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 50 percent of the frame width, generous empty margins left and right. No text, no graphics, no logos, no people's faces.
```

## czip-04-skaner

```text
# Czytnik czipów
Plik: czip-04-skaner.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 4:5 portrait. Subject: a handheld microchip reader held near a dog's shoulder. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## czip-05-pies-kot

```text
# Kot i pies w poczekalni
Plik: czip-05-pies-kot.png. Narzędzie: wbudowane image_gen.

Use case: stylized-concept. Asset type: website cutout, 1:1 square. Subject: a calm grey cat and a small dog sitting side by side, seen from the front. True transparent alpha background, no halo, no drop shadow. Grayscale black-and-white photographic rendering, soft diffused studio light. Subject within the middle 70 percent of the frame. No text, no logos.
```

## zespol-00-hero

```text
# Ilustracja hero
Plik: zespol-00-hero.png. Narzędzie: wbudowane image_gen.

Use case: scientific-educational illustration. Asset type: website diagram, 1:1 square. Subject: a friendly veterinarian crouching to greet a dog and a cat, seen from the side. Monoline black line art on transparent background, no fill, even stroke width, consistent with the clinic's existing line illustrations. No text, no numbers, no gradients, no shading.

Style references (attach all as image inputs and match their line weight, proportions, calm mood and level of detail; do NOT copy their subjects): assets/illustrations/services/service-internal-a.png, assets/illustrations/services/service-cardiology-b.png, assets/illustrations/services/service-eyes-a.png, assets/illustrations/services/service-dentistry-a.png.
Reject any result that looks generic, glossy, 3D, cartoon-mascot or stock-vector.
```

## zespol-01-zespol-grupowe

```text
# Zespół przychodni
Plik: zespol-01-zespol-grupowe.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 21:9 wide panoramic banner. Subject: a group of seven women veterinarians in white coats standing together in a bright clinic, wide group portrait. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 50 percent of the frame width, generous empty margins left and right. No text, no graphics, no logos, no people's faces.
```

## zespol-03-atmosfera

```text
# Pies w gabinecie
Plik: zespol-03-atmosfera.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 21:9 wide panoramic banner. Subject: a dog sitting calmly next to a veterinarian's legs in a clinic, no faces, wide 21:9 composition. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 60 percent of the frame. No text, no graphics, no logos, no people's faces.
```

## zespol-02-gabinet

```text
# Gabinet
Plik: zespol-02-gabinet.jpg. Narzędzie: wbudowane image_gen.

Use case: photorealistic-natural. Asset type: website photograph, 21:9 wide panoramic banner. Subject: a quiet veterinary consulting room with a desk and a window. Grayscale black-and-white photographic rendering, flat very light neutral grey seamless backdrop (#d4d4d4), soft diffused studio light, low-contrast editorial look. Subject within the middle 50 percent of the frame width, generous empty margins left and right. No text, no graphics, no logos, no people's faces.
```

