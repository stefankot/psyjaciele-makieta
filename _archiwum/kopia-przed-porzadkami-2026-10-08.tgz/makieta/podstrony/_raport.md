<!-- generated: psyjaciele-podstrony -->
# Raport — podstrony Psyjaciół (8.10.2026)

## 1. Co powstało
- 17 stron (hub, 14 usług, zespół, polityka) + `podstrony/index.html` (przegląd, noindex), `podstrony.css`, `podstrony.js`.
- `_bloki.html` (N1–N27 w 4 paletach: soft-a, mid-c, paper, booking; N23 tylko w mid-c — karty osób mają style tylko w `.team`).
- `_obrazy.json` (źródło prawdy, 70 obrazów), `_obrazy.md`, `OBRAZY-PROMPTY.md`; `_narzedzia/` (build, strony, plany, bloki, bloki_demo, manifest, home, obrazy, zrodlo, checks, audit, generuj_obrazy).
- Build jest idempotentny; pliki bez znacznika `generated: psyjaciele-podstrony` nie są nadpisywane.

## 2. Zmiany poza `podstrony/` (na wyraźne polecenie użytkownika, wyjątek od R3)
- `layout-warianty/layout-nowa.css`: numeracja w `#przychodnia` (Rialto 56 px) → Satoshi 900 w kole, cyfry 1, 2, 3 (bez zera wiodącego).
- Nic więcej.

## 3. Zasady z ostatnich uwag użytkownika — stan
- Punktory: Satoshi w kole, cyfry bez zera (1, 2, 3) — spis treści, `ruled-list.is-numbered`, `step-list`, `equipment-grid`, numery sekcji w nagłówkach. Rialto zostaje tylko w tytułach (`em`) i wartościach (`phase-when`, `range-value`, „vs”, licznik oddechów) — to nie punktory.
- Ilustracje z podstron usunięte: hero = placeholder `*-00-hero` (rodzaj „ilustracja”, 16 sztuk, prompty EN z listą referencji stylu); kafle „Zobacz też” bez ilustracji. Bento na hubie i bloki skopiowane z home (kontakt, rekomendacje, nagłe przypadki) używają plików, które są też na home — nie ruszałem ich.
- Kontakt na podstronach: wiersze „etykieta | treść” zamiast 3 kolumn o różnej długości (równe odstępy pionowe).

## 4. Zweryfikowane (uruchomione)
| Kontrola | Wynik |
|---|---|
| Pokrycie tekstu źródłowego (V1), linki (V2), duplikaty id (V4), nagłówki (V5), literały kolorów (V6), liczba placeholderów 3–7 (V13), brak minimal*.js (V14) | `checks.py`: 17/17 bez błędów |
| Audyt Chromium 1440/1024/768/390 × 17 stron | 0 przepełnień poziomych, 0 fontów < 16 px, 0 błędów JS |
| Zrzuty ekranu | `_zrzuty/` (68 plików); oglądałem ręcznie: okulistyka, kardiologia, czipowanie, hub, zespół, `_bloki` (wycinki) |

## 5. Niesprawdzone / znane ograniczenia (uczciwie)
- **Zrzuty 1024 i 768 przejrzałem tylko wyrywkowo**; pełny przegląd wzrokowy wszystkich 68 nie został wykonany.
- Logi konsoli: placeholdery sondują pliki obrazów (`new Image()`), więc przeglądarka loguje 404 do czasu wgrania plików (`ph_404` w `_audyt.json`, 64 wpisy). To nie błąd strony.
- Nie napisałem: `klasy.py`, `paleta-test.js`/`baseline.json` (V3), testu siatki 8 px (V16), V11 (symulacja podkatalogu), V12 (macierz pokrycia bloków), V18 (nawigacja klawiaturą); `--bake` nie jest zaimplementowane (podmiana obrazów działa w przeglądarce).
- Plan stron to generyczny silnik (`plany.py`), nie ręczne kompozycje z §10 dla każdej strony: część „sygnatur” (np. kolejność figure-band w dermatologii, duo+H6 w nefro/uro, rail-layout 7 układów w interna) jest tylko przybliżona. Pokrycie globalne z §8.4 liczyłem orientacyjnie, nie skryptem.
- Wpis rejestru `kard-05-pas` nie jest użyty (limit 7 placeholderów na stronę).
- Treść: home nie ma `h1` (zgłoszone zgodnie z §), rozbieżność w wzmiance o Julii w źródłach vs. home nie została rozstrzygnięta. Ukryte nagłówki dodane przeze mnie: „Usługi w skrócie” (bento), „Umów wizytę” (cta-band); tekst „Lekarki prowadzące / Kto przyjmuje” w doctor-strip to element interfejsu, nie treść źródłowa.
- N23 doctor-strip w tabeli zespołu (miniatury) i `article.person` w profilach zespołu: nie zrobione.
- `_bloki.html`: paleta booking ma mniejszy górny odstęp etykiety (padding z home) — kosmetyka.
- `generuj_obrazy.py` jest **nieprzetestowany** (brak dostępu do API z tego środowiska) — formaty żądań [NIEZWERYFIKOWANE].

## 6. Generowanie ilustracji
Z tego środowiska `api.openai.com` i `generativelanguage.googleapis.com` są nieosiągalne (HTTP 000, sprawdzone z kontenera i z powłoki na komputerze). Opcje: patrz odpowiedź w rozmowie.

## 7. Zmiany po uwagach użytkownika (8.10.2026, później)
- Usunięte: numeracja sekcji (kickery z cyframi), okruszki i kicker „Usługa” w hero, fact-strip w hero, spis treści i sekcja „Którą lekarkę wybrać” na stronie Zespół, etykiety „Zobacz też”, „Lekarki prowadzące”, „Na skróty”, „Ważne”. Zostają etykiety kryzysowe („Pilne”).
- Dodane: strzałka cofania na lewo od h1 (do huba usług / strony głównej).
- Zespół: nowy układ profili (portret nieprzycięty, naprzemiennie), „Lekarka weterynarii” zamiast „lek. wet.” w nagłówkach; „Praca w Psyjaciołach” jako nagłówek + akapit (bez ramki i obrazu obok); pas zdjęcia gabinetu (`zespol-02-gabinet`, 21:9).
- Strona główna (index-min, index-nowa) i Zespół: usunięty akapit „lek. wet. … — choroby wewnętrzne …” (obszary lekarek).
- Podstrony podpięte do strony głównej (kafle usług → `podstrony/…`).
- Generowanie obrazów nadal zablokowane (brak dostępu do API); `generuj_obrazy.py` nieprzetestowany.

## 8. Uwagi z narzędzia „Uwagi” (8.10.2026) — zastosowane na wszystkich podstronach
- Hero: tło łososiowe (zmienne palety `.team`), ilustracja szersza (5 z 12 kolumn, +18% skali), akapit „Umów wizytę” w tym samym foncie co akapit wiodący (20/32), telefony bez zawijania (`white-space:nowrap`), przyciski o jednakowej szerokości i paddingach, większy odstęp od dołu, przyciski i status w kolorach zmiennych sekcji.
- Znaczniki wiszą poza kolumną tekstu (tekst zaczyna się w jednej linii): strzałka powrotu (w kółku, kreska = 0,13 em kickera tytułu), strzałki w listach z kreskami i w podpunktach spisu treści (zamiast kwadratów i pionowej kreski), koła z cyframi w krokach. Strzałki: kreska 2,2 px ≈ 0,13 em Satoshi (zmierzone: trzon „I” = 0,13 em). Wiszenie: strzałki od 1001 px, koła i strzałka powrotu od 1440 px; poniżej znacznik jest w linii (brak marginesu).
- „Pilne — Co zrobić”: etykieta scalona z wersalikowym nagłówkiem; ilustracja nagłówka powiększona.
- Baner „Praca w Psyjaciołach”: poziomy, wyśrodkowany (Zespół) i pionowy w bocznej szpalcie (lewa/prawa na przemian) przy sekcji FAQ na 11 stronach usług z akordeonem; 3 strony z FAQ w kolumnach (diagnostyka laboratoryjna, stomatologia, szczepienia) bez banera. Obraz banera: `zespol-03-atmosfera` (1:1), ten sam plik na wszystkich stronach.
- Narzędzie do uwag: `?uwagi=1` albo zakładka (patrz `_narzedzia/UWAGI.md`).
